./sim 1 5
./sim 1 4321
./sim 1 1234

./sim 2 5
./sim 2 4321
./sim 2 1234

./sim 4 5
./sim 4 4321
./sim 4 1234
